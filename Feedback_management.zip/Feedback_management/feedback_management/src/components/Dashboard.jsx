import React, { useEffect } from 'react';
import './Dashboard.css';

const Dashboard = () => {
  useEffect(() => {
    document.title = "Dashboard";
  }, []);

  return (
    <div className="dashboard-container">
      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <h2>Dashboard</h2>
        </div>
        <nav className="sidebar-nav">
          <ul>
            <li className="active">
              <span className="nav-icon">📊</span>
              <span className="nav-text">Dashboard</span>
            </li>
            <li>
              <span className="nav-icon">📂</span>
              <span className="nav-text">Projects</span>
            </li>
            <li>
              <span className="nav-icon">👥</span>
              <span className="nav-text">Team</span>
            </li>
            <li>
              <span className="nav-icon">⚙️</span>
              <span className="nav-text">Settings</span>
            </li>
            <li className="logout-item">
              <span className="nav-icon">🚪</span>
              <span className="nav-text">Logout</span>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        <div className="content-wrapper">
          <header className="content-header">
            <h1>Welcome to Your Dashboard</h1>
            <p className="subtitle">Track, manage, and collaborate on your projects efficiently.</p>
          </header>

          <hr className="content-divider" />

          <section className="project-description">
            <h2>Project Description</h2>
            <div className="description-content">
              <p>
                This web application allows users to sign in, register, and view a dashboard containing project and team details.
                It is built using React for the frontend and Node.js for the backend. The design emphasizes usability, responsiveness,
                and a smooth user experience.
              </p>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;