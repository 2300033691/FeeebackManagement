import React, { useState } from 'react';
import './FeedbackForm.css';

const FeedbackForm = ({ productId, productName }) => {
  const [feedback, setFeedback] = useState({
    name: '',
    email: '',
    message: '',
    rating: 5,
  });
  const [status, setStatus] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      ...feedback,
      productId,
      productName,
    };

    try {
      const response = await fetch('http://localhost:8080/api/product-feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        setStatus('success');
        setFeedback({ name: '', email: '', message: '', rating: 5 });
      } else {
        setStatus('error');
      }
    } catch (error) {
      console.error('Submission error:', error);
      setStatus('error');
    }
  };

  return (
    <div className="feedback-page-wrapper">
      <div className="feedback-form-container">
        <h2>Rate This Product</h2>
        <p><strong>Product:</strong> {productName}</p>

        <form onSubmit={handleSubmit}>
          <div>
            <label>Your Name (optional):</label>
            <input
              type="text"
              value={feedback.name}
              onChange={(e) => setFeedback({ ...feedback, name: e.target.value })}
            />
          </div>
          <div>
            <label>Email (optional):</label>
            <input
              type="email"
              value={feedback.email}
              onChange={(e) => setFeedback({ ...feedback, email: e.target.value })}
            />
          </div>
          <div>
            <label>Your Review:</label>
            <textarea
              placeholder="What did you like or dislike about this product?"
              value={feedback.message}
              onChange={(e) => setFeedback({ ...feedback, message: e.target.value })}
              required
            />
          </div>
          <div>
            <label>Rating:</label>
            <select
              value={feedback.rating}
              onChange={(e) => setFeedback({ ...feedback, rating: parseInt(e.target.value) })}
            >
              <option value={5}>★★★★★ - Excellent</option>
              <option value={4}>★★★★ - Good</option>
              <option value={3}>★★★ - Average</option>
              <option value={2}>★★ - Poor</option>
              <option value={1}>★ - Terrible</option>
            </select>
          </div>
          <button type="submit">Submit Review</button>
        </form>

        {status === 'success' && <p className="success-msg">Thank you for your feedback!</p>}
        {status === 'error' && <p className="error-msg">Failed to submit. Please try again later.</p>}
      </div>
    </div>
  );
};

export default FeedbackForm;
