import React from 'react';

const Profile = ({ user }) => {
  if (!user) {
    return <p>Please sign in to view your profile.</p>;
  }

  return (
    <div>
      <h2>{user.name}'s Profile</h2>
      <p>Email: {user.email}</p>
      <p>Joined: {new Date().toLocaleDateString()}</p>
    </div>
  );
};

export default Profile;
