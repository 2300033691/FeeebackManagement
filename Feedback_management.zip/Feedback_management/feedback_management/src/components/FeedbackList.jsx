import React, { useEffect, useState } from 'react';
import './FeedbackList.css';

const FeedbackList = () => {
  const [feedbacks, setFeedbacks] = useState([]);

  useEffect(() => {
    const fetchFeedbacks = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/feedback');
        const data = await response.json();
        setFeedbacks(data);
      } catch (error) {
        console.error('Error fetching feedbacks:', error);
      }
    };
    fetchFeedbacks();
  }, []);

  return (
    <div className="feedback-list-wrapper">
      <div className="feedback-list-container">
        <h2>Feedback List</h2>
        <ul>
          {feedbacks.map((feedback, index) => (
            <li key={index}>
              <strong>{feedback.name}</strong> <span className="rating">({feedback.rating} stars)</span>
              <p>{feedback.message}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default FeedbackList;
