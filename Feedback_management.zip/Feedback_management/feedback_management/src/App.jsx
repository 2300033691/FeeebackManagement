import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import Profile from './components/Profile';
import Dashboard from './components/Dashboard';
import FeedbackForm from './components/FeedbackForm';
import FeedbackList from './components/FeedbackList';
import './App.css';

const App = () => {
  const [user, setUser] = useState(null);
  const [feedbacks, setFeedbacks] = useState([]);

  const handleSignIn = (userData) => {
    setUser(userData);
  };

  const handleSignUp = (userData) => {
    setUser(userData);
  };

  const handleSignOut = () => {
    setUser(null);
    setFeedbacks([]); // Optional: clear feedback on logout
  };

  const handleFeedbackSubmit = (message) => {
    setFeedbacks([...feedbacks, { user: user.name, message }]);
  };

  return (
    <Router>
      <div className="app-container">
        {/* Navigation Bar */}
        <nav>
          <ul>
            <li><Link to="/">Home</Link></li>
            {!user && <li><Link to="/signin">Sign In</Link></li>}
            {!user && <li><Link to="/signup">Sign Up</Link></li>}
            {user && <li><Link to="/profile">Profile</Link></li>}
            {user && <li><Link to="/dashboard">Dashboard</Link></li>}
            {user && <li><Link to="/feedback">Feedback</Link></li>}
            {user && <li><button onClick={handleSignOut}>Sign Out</button></li>}
          </ul>
        </nav>

        {/* Main Content Area */}
        <div className="main-content">
          <div className="card">
            <Routes>
              <Route
                path="/"
                element={
                  <div className="home-content">
                    <h1>Feedback Management System</h1>
                    <p>
                      Welcome to the Feedback Management System. This application allows users to securely sign in, submit feedback,
                      and view performance dashboards.
                    </p>
                    {!user ? (
                      <p>Please sign in or sign up to get started.</p>
                    ) : (
                      <p>Hello, {user.name}! Use the navigation above to explore your dashboard and profile.</p>
                    )}
                  </div>
                }
              />
              <Route path="/signin" element={<SignIn onSignIn={handleSignIn} />} />
              <Route path="/signup" element={<SignUp onSignUp={handleSignUp} />} />
              <Route path="/profile" element={user ? <Profile user={user} /> : <Navigate to="/signin" />} />
              <Route path="/dashboard" element={user ? <Dashboard user={user} /> : <Navigate to="/signin" />} />
              <Route
                path="/feedback"
                element={
                  user ? (
                    <div>
                      <FeedbackForm onSubmitFeedback={handleFeedbackSubmit} />
                      <FeedbackList feedbacks={feedbacks} />
                    </div>
                  ) : (
                    <Navigate to="/signin" />
                  )
                }
              />
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
};

export default App;
