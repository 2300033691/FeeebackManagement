package com.example.auth_service.service;

import com.example.auth_service.entity.User;
import com.example.auth_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new RuntimeException("User already exists with email: " + user.getEmail());
        }
        if (user.getRole().equalsIgnoreCase("ARTISAN")) {
            user.setIsApproved(false);
        }
        return userRepository.save(user);
    }

    public User authenticateUser(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));

        if (!user.getPassword().equals(password)) {
            throw new RuntimeException("Invalid credentials.");
        }

        if (user.getRole().equalsIgnoreCase("ARTISAN") && !Boolean.TRUE.equals(user.getIsApproved())) {
            throw new RuntimeException("Artisan account is not approved by the admin.");
        }

        return user;
    }

    public User updateUserProfile(User updatedUser) {
        User existingUser = userRepository.findByEmail(updatedUser.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found with email: " + updatedUser.getEmail()));

        existingUser.setName(updatedUser.getName());
        existingUser.setPhone(updatedUser.getPhone());
        existingUser.setAddress(updatedUser.getAddress());

        return userRepository.save(existingUser);
    }

    public User updateArtisanProfile(User updatedArtisan) {
        User existingArtisan = userRepository.findByEmail(updatedArtisan.getEmail())
                .orElseThrow(() -> new RuntimeException("Artisan not found with email: " + updatedArtisan.getEmail()));

        existingArtisan.setName(updatedArtisan.getName());
        existingArtisan.setPhone(updatedArtisan.getPhone());
        existingArtisan.setAddress(updatedArtisan.getAddress());
        existingArtisan.setWorkType(updatedArtisan.getWorkType());
        existingArtisan.setDescription(updatedArtisan.getDescription());

        return userRepository.save(existingArtisan);
    }

    public User approveArtisan(Long id) {
        User artisan = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Artisan not found with ID: " + id));
        if (!"ARTISAN".equalsIgnoreCase(artisan.getRole())) {
            throw new RuntimeException("User with ID: " + id + " is not an artisan.");
        }
        artisan.setIsApproved(true);
        return userRepository.save(artisan);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
    }
}
