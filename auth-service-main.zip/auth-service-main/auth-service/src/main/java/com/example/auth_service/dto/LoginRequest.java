package com.example.auth_service.dto;

public class LoginRequest {
    private String email;
    private String password;

    // Getters and Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email; // Email used to identify feedback submitter or admin
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password; // Password for authenticating access to feedback system
    }
}
